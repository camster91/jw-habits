# JW-News Meeting Share Link Feature - Complete Package

## 📦 What's Included

This package contains everything you need to add JW Library meeting share links to your JW-News app.

### Files:
1. **JW_NEWS_IMPLEMENTATION_PLAN.md** - Full detailed implementation guide
2. **CLAUDE_CODE_QUICKSTART.md** - Quick start guide for Claude Code
3. **linkConverter.js** - Core link conversion utility
4. **dateUtils.js** - Week/date calculation utilities
5. **MeetingCard.jsx** - React component (MVP version)
6. **MeetingCard.css** - Component styles
7. **README.md** - This file

---

## 🚀 Quick Start (5 Minutes)

### Step 1: Copy Files to Your Project

```bash
# Navigate to your JW-News project
cd /path/to/JW-News

# Create directories
mkdir -p src/services src/components/Meeting

# Copy the files
# Copy linkConverter.js → src/services/
# Copy dateUtils.js → src/services/
# Copy MeetingCard.jsx → src/components/Meeting/
# Copy MeetingCard.css → src/components/Meeting/
```

### Step 2: Update File Imports

In `MeetingCard.jsx`, update the import paths if needed:
```javascript
import { getCurrentWeekDocId, getWeekDateRange } from '../../services/dateUtils';
import { convertToAppLink } from '../../services/linkConverter';
```

### Step 3: Add to Your App

In your main component (e.g., `App.jsx` or `Home.jsx`):

```javascript
import MeetingCard from './components/Meeting/MeetingCard';

function App() {
  return (
    <div className="app">
      {/* Your existing content */}
      
      <MeetingCard />
      
      {/* Rest of your content */}
    </div>
  );
}
```

### Step 4: Test It

```bash
npm start
```

Visit your app and you should see the meeting card with a button to open in JW Library!

---

## ✨ Features

✅ **Works Immediately** - No API keys, no backend required
✅ **No Network Requests** - Generates links client-side (no CORS issues)
✅ **Automatic Week Detection** - Always shows current week
✅ **Mobile-Friendly** - Deep links work on iOS and Android
✅ **Copy Link** - Easy sharing with copy button
✅ **View Online** - Fallback to wol.jw.org
✅ **Responsive Design** - Looks great on all devices
✅ **Dark Mode Support** - Adapts to system theme

---

## 📱 How It Works

### 1. Week Calculation
The `dateUtils.js` calculates the current week number using ISO 8601 standard:
- Week 1 is the week containing January 4th
- Weeks run Monday-Sunday

### 2. DocID Generation
Creates a document ID in the format: `YEAR + 6 + WEEK`
- Example: Week 42 of 2025 = `2025642`
- The `6` is a constant prefix used by JW.org

### 3. Link Conversion
Converts the format from web share link to app deep link:

**Web Share Link:**
```
https://www.jw.org/finder?wtlocale=E&docid=2025642&srctype=wol&srcid=share
```

**App Deep Link:**
```
https://www.jw.org/finder?srcid=jwlshare&wtlocale=E&prefer=lang&docid=2025642
```

Key changes:
- `srcid=share` → `srcid=jwlshare`
- Added: `prefer=lang`
- Removed: `srctype=wol`

---

## 🎨 Customization

### Change Locale/Language

```javascript
// For Spanish
<MeetingCard locale="S" language="es" />

// For French
<MeetingCard locale="F" language="fr" />
```

### Customize Styles

Edit `MeetingCard.css` to match your app's theme:

```css
.meeting-card {
  /* Change colors */
  background: #your-color;
  
  /* Change border radius */
  border-radius: 8px;
  
  /* Change shadows */
  box-shadow: your-shadow;
}

.btn-primary {
  /* Change button color */
  background: linear-gradient(135deg, #your-gradient);
}
```

### Add Additional Buttons

Edit `MeetingCard.jsx` to add more actions:

```javascript
<div className="meeting-actions">
  <button onClick={handleOpenApp} className="btn-primary">
    📱 Open in JW Library
  </button>
  
  <button onClick={handleCopyLink} className="btn-secondary">
    {copied ? '✓ Copied' : '📋 Copy Link'}
  </button>
  
  {/* Add your custom button */}
  <button onClick={handleCustomAction} className="btn-secondary">
    🔔 Set Reminder
  </button>
</div>
```

---

## 🔧 Advanced Features

### Week Navigation

Want users to see other weeks? Add navigation:

```javascript
import { getNextWeekDocId, getPreviousWeekDocId } from '../../services/dateUtils';

function MeetingCardWithNav() {
  const [docid, setDocid] = useState(getCurrentWeekDocId());
  
  const goToNextWeek = () => {
    setDocid(getNextWeekDocId());
  };
  
  const goToPreviousWeek = () => {
    setDocid(getPreviousWeekDocId());
  };
  
  return (
    <>
      <div className="week-nav">
        <button onClick={goToPreviousWeek}>← Previous Week</button>
        <button onClick={goToNextWeek}>Next Week →</button>
      </div>
      <MeetingCard docid={docid} />
    </>
  );
}
```

### Network Fetching (Optional)

To fetch actual meeting titles and content:

```javascript
import { useState, useEffect } from 'react';

function MeetingCardWithFetch({ docid }) {
  const [meeting, setMeeting] = useState(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    async function fetchMeeting() {
      try {
        const url = `https://wol.jw.org/en/wol/d/r1/lp-e/${docid}`;
        const response = await fetch(url);
        const html = await response.text();
        
        // Parse HTML to extract title
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const title = doc.querySelector('h1')?.textContent || 'This Week\'s Meeting';
        
        setMeeting({ title, docid });
      } catch (error) {
        console.error('Error fetching meeting:', error);
      } finally {
        setLoading(false);
      }
    }
    
    fetchMeeting();
  }, [docid]);
  
  if (loading) return <div>Loading...</div>;
  
  return <MeetingCard meeting={meeting} />;
}
```

**Note:** This approach may have CORS issues. See the implementation plan for backend solutions.

---

## 🐛 Troubleshooting

### Problem: Link doesn't open JW Library app

**Solution:** 
- Ensure JW Library is installed on the device
- Test on an actual mobile device (not browser)
- Check that the deep link format is correct

### Problem: Week number seems wrong

**Solution:**
- Verify your system date/time is correct
- Check timezone settings
- ISO 8601 week standard: Week 1 contains January 4th

### Problem: Buttons don't work

**Solution:**
- Check browser console for errors
- Verify imports are correct
- Make sure React is properly set up

### Problem: Styles look wrong

**Solution:**
- Check that `MeetingCard.css` is imported
- Verify CSS class names match
- Check for conflicting global styles

---

## 📋 Testing Checklist

Before deploying, test:

- [ ] Meeting card displays correctly
- [ ] Current week is accurate
- [ ] "Open in JW Library" button works
- [ ] Copy link button copies to clipboard
- [ ] View online button opens wol.jw.org
- [ ] Works on desktop browsers
- [ ] Works on mobile Safari (iOS)
- [ ] Works on mobile Chrome (Android)
- [ ] Deep link opens JW Library when installed
- [ ] Styles look good in light mode
- [ ] Styles look good in dark mode (if supported)
- [ ] Responsive on different screen sizes

---

## 🚢 Deployment

### Build for Production

```bash
npm run build
```

### Deploy

Your usual deployment process (Netlify, Vercel, etc.)

---

## 📚 Additional Documentation

- **Full Implementation Guide**: See `JW_NEWS_IMPLEMENTATION_PLAN.md`
- **Claude Code Guide**: See `CLAUDE_CODE_QUICKSTART.md`

---

## 🤝 Support

### If Something Breaks

1. Check browser console for errors
2. Verify all files are in the correct locations
3. Check import paths
4. Test with a hardcoded docid to isolate the issue:
   ```javascript
   <MeetingCard docid="2025642" />
   ```

### Common Issues

**"Cannot find module"** - Check import paths
**"undefined is not a function"** - Check function exports/imports
**Link doesn't work** - Verify docid format is correct (7 digits)

---

## 🎯 Next Steps

After getting the basic version working:

1. ✅ Add week navigation
2. ✅ Fetch real meeting titles (if you can solve CORS)
3. ✅ Add analytics tracking
4. ✅ Add meeting reminders
5. ✅ Cache meeting data
6. ✅ Add multi-language support
7. ✅ Create backend API for better data fetching

---

## 📝 Credits

- Link conversion logic discovered by analyzing JW.org URLs
- Week calculation uses ISO 8601 standard
- Component design inspired by modern React patterns

---

## 📄 License

Free to use for personal and congregation purposes.

---

## 🎉 That's It!

You now have a working meeting share link feature. Users can:
- See the current week's meeting
- Click to open directly in JW Library app
- Copy the link to share
- View on wol.jw.org as a fallback

Enjoy! 🎊
