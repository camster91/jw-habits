/**
 * Link Converter Utility
 * Converts JW.org web share links to JW Library app deep links
 */

/**
 * Convert JW.org web share link to JW Library app deep link
 * @param {string} webShareLink - Original web share link (optional if docid provided)
 * @param {string} wtlocale - Locale code (default: 'E' for English)
 * @param {string} docid - Document ID (required if webShareLink not provided)
 * @returns {string} App deep link
 * 
 * @example
 * // From web link
 * convertToAppLink('https://www.jw.org/finder?wtlocale=E&docid=2025642&srctype=wol&srcid=share')
 * // Returns: 'https://www.jw.org/finder?srcid=jwlshare&wtlocale=E&prefer=lang&docid=2025642'
 * 
 * // From docid
 * convertToAppLink(null, 'E', '2025642')
 * // Returns: 'https://www.jw.org/finder?srcid=jwlshare&wtlocale=E&prefer=lang&docid=2025642'
 */
export function convertToAppLink(webShareLink = null, wtlocale = 'E', docid = null) {
  // Parse existing link if provided
  if (webShareLink && webShareLink.includes('finder')) {
    try {
      const url = new URL(webShareLink);
      const params = new URLSearchParams(url.search);
      wtlocale = params.get('wtlocale') || wtlocale;
      docid = params.get('docid') || docid;
    } catch (error) {
      console.error('Error parsing web share link:', error);
    }
  }
  
  if (!docid) {
    throw new Error('docid is required to generate app deep link');
  }
  
  // Build app deep link with correct parameters
  const appParams = new URLSearchParams({
    srcid: 'jwlshare',
    wtlocale: wtlocale,
    prefer: 'lang',
    docid: docid
  });
  
  return `https://www.jw.org/finder?${appParams.toString()}`;
}

/**
 * Build web share link from docid
 * @param {string} docid - Document ID
 * @param {string} wtlocale - Locale code (default: 'E')
 * @returns {string} Web share link
 */
export function buildWebShareLink(docid, wtlocale = 'E') {
  const params = new URLSearchParams({
    wtlocale: wtlocale,
    docid: docid,
    srctype: 'wol',
    srcid: 'share'
  });
  
  return `https://www.jw.org/finder?${params.toString()}`;
}

/**
 * Validate docid format
 * @param {string} docid - Document ID to validate
 * @returns {boolean} True if valid
 */
export function isValidDocId(docid) {
  // Format: YYYY0WW (e.g., 2025642 for year 2025, week 42)
  const pattern = /^\d{7}$/;
  return pattern.test(docid);
}
