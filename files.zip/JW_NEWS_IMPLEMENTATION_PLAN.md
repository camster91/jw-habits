# JW-News Meeting Share Link Integration Plan

## 🎯 Project Goal
Add functionality to JW-News app to automatically find and convert the current week's meeting share link to a JW Library app deep link.

---

## 📋 Feature Requirements

### User Story
As a user, I want to:
1. See the current week's meeting in the app
2. Click a button/link that opens the meeting directly in JW Library app
3. Have this work automatically without manual link copying

### Technical Requirements
1. Automatically detect current week's meeting from wol.jw.org
2. Extract the share link from the meeting page
3. Convert web share link to app deep link
4. Display clickable link/button in the UI
5. Handle errors gracefully (no meeting, network issues, etc.)

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                    JW-News Frontend                     │
│                                                         │
│  ┌─────────────────────────────────────────────────┐  │
│  │         Meeting Component                       │  │
│  │  - Display current week meeting info            │  │
│  │  - Show "Open in JW Library" button             │  │
│  │  - Handle click to open deep link               │  │
│  └─────────────────────────────────────────────────┘  │
│                         │                              │
│                         ▼                              │
│  ┌─────────────────────────────────────────────────┐  │
│  │      Meeting Service/API Module                 │  │
│  │  - getCurrentWeekMeeting()                      │  │
│  │  - getMeetingShareLink(docid)                   │  │
│  │  - convertToAppLink(webLink)                    │  │
│  └─────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────┐
│                Backend/API (Optional)                   │
│  - Cache meeting data                                   │
│  - Rate limit wol.jw.org requests                       │
│  - Serve meeting links via REST API                     │
└─────────────────────────────────────────────────────────┘
```

---

## 📁 File Structure

```
jw-news/
├── src/
│   ├── components/
│   │   ├── Meeting/
│   │   │   ├── MeetingCard.jsx          # NEW: Display meeting info
│   │   │   ├── MeetingShareButton.jsx   # NEW: Open in JW Library button
│   │   │   └── MeetingWeekSelector.jsx  # NEW: Navigate weeks
│   │   └── ...existing components
│   │
│   ├── services/
│   │   ├── meetingService.js            # NEW: Core meeting logic
│   │   ├── linkConverter.js             # NEW: Link conversion utils
│   │   └── dateUtils.js                 # NEW: Date/week calculations
│   │
│   ├── api/
│   │   └── meetings.js                  # NEW: API routes (if backend)
│   │
│   ├── hooks/
│   │   ├── useMeeting.js                # NEW: React hook for meetings
│   │   └── useCurrentWeek.js            # NEW: Get current week data
│   │
│   └── utils/
│       ├── constants.js                 # NEW: URLs, locale codes, etc.
│       └── ...existing utils
│
├── server/                              # If using backend
│   ├── routes/
│   │   └── meetings.js                  # NEW: Meeting API endpoints
│   └── services/
│       └── meetingScraper.js            # NEW: Server-side scraping
│
└── package.json                         # Updated dependencies
```

---

## 🔧 Implementation Steps

### Phase 1: Core Utilities (Start Here)

#### Step 1.1: Link Converter Utility
**File:** `src/services/linkConverter.js`

```javascript
/**
 * Convert JW.org web share link to JW Library app deep link
 * @param {string} webShareLink - Original web share link
 * @param {string} wtlocale - Locale code (default: 'E')
 * @param {string} docid - Document ID
 * @returns {string} App deep link
 */
export function convertToAppLink(webShareLink, wtlocale = 'E', docid = null) {
  // Parse existing link if provided
  if (webShareLink && webShareLink.includes('finder')) {
    const url = new URL(webShareLink);
    const params = new URLSearchParams(url.search);
    wtlocale = params.get('wtlocale') || wtlocale;
    docid = params.get('docid') || docid;
  }
  
  // Build app deep link
  const appParams = new URLSearchParams({
    srcid: 'jwlshare',
    wtlocale: wtlocale,
    prefer: 'lang',
    docid: docid
  });
  
  return `https://www.jw.org/finder?${appParams.toString()}`;
}

/**
 * Build web share link from docid
 */
export function buildWebShareLink(docid, wtlocale = 'E') {
  const params = new URLSearchParams({
    wtlocale: wtlocale,
    docid: docid,
    srctype: 'wol',
    srcid: 'share'
  });
  
  return `https://www.jw.org/finder?${params.toString()}`;
}
```

#### Step 1.2: Date Utilities
**File:** `src/services/dateUtils.js`

```javascript
/**
 * Get current week number (1-52)
 */
export function getCurrentWeekNumber() {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 1);
  const diff = now - start;
  const oneWeek = 1000 * 60 * 60 * 24 * 7;
  return Math.ceil(diff / oneWeek);
}

/**
 * Get current year
 */
export function getCurrentYear() {
  return new Date().getFullYear();
}

/**
 * Calculate docid for a given year and week
 * Format: YEAR + 0 + WEEK (e.g., 2025 + 0 + 42 = 2025642)
 */
export function getDocIdForWeek(year, week) {
  // Pad week to 2 digits if needed
  const weekPadded = week.toString().padStart(2, '0');
  return `${year}0${weekPadded}`;
}

/**
 * Get current week's docid
 */
export function getCurrentWeekDocId() {
  const year = getCurrentYear();
  const week = getCurrentWeekNumber();
  return getDocIdForWeek(year, week);
}

/**
 * Get date range string for a week
 * @param {Date} date - Any date in the week
 * @returns {string} "January 6-12, 2025"
 */
export function getWeekDateRange(date = new Date()) {
  // Get Monday of the week
  const day = date.getDay();
  const diff = date.getDate() - day + (day === 0 ? -6 : 1);
  const monday = new Date(date.setDate(diff));
  
  // Get Sunday
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  
  const monthName = monday.toLocaleString('en-US', { month: 'long' });
  const year = monday.getFullYear();
  
  return `${monthName} ${monday.getDate()}-${sunday.getDate()}, ${year}`;
}
```

#### Step 1.3: Constants
**File:** `src/utils/constants.js`

```javascript
// Base URLs
export const WOL_BASE_URL = 'https://wol.jw.org';
export const FINDER_BASE_URL = 'https://www.jw.org/finder';

// Default locale settings
export const DEFAULT_LOCALE = 'E'; // English
export const DEFAULT_LANGUAGE = 'en';

// URL patterns
export const MEETINGS_URL_PATTERN = (year, month, locale = 'E', lang = 'en') =>
  `${WOL_BASE_URL}/${lang}/wol/meetings/r1/lp-${locale.toLowerCase()}/${year}/${month}`;

export const MEETING_URL_PATTERN = (docid, locale = 'E', lang = 'en') =>
  `${WOL_BASE_URL}/${lang}/wol/d/r1/lp-${locale.toLowerCase()}/${docid}`;

// Cache duration
export const CACHE_DURATION_MS = 1000 * 60 * 60; // 1 hour
```

---

### Phase 2: Meeting Service

#### Step 2.1: Meeting Service
**File:** `src/services/meetingService.js`

```javascript
import { 
  convertToAppLink, 
  buildWebShareLink 
} from './linkConverter';
import { 
  getCurrentWeekDocId, 
  getWeekDateRange,
  getCurrentYear 
} from './dateUtils';
import {
  WOL_BASE_URL,
  MEETINGS_URL_PATTERN,
  MEETING_URL_PATTERN,
  DEFAULT_LOCALE,
  DEFAULT_LANGUAGE
} from '../utils/constants';

/**
 * Get current week's meeting data
 */
export async function getCurrentWeekMeeting(locale = DEFAULT_LOCALE, lang = DEFAULT_LANGUAGE) {
  try {
    const docid = getCurrentWeekDocId();
    return await getMeetingByDocId(docid, locale, lang);
  } catch (error) {
    console.error('Error getting current week meeting:', error);
    throw error;
  }
}

/**
 * Get meeting data by document ID
 */
export async function getMeetingByDocId(docid, locale = DEFAULT_LOCALE, lang = DEFAULT_LANGUAGE) {
  try {
    const url = MEETING_URL_PATTERN(docid, locale, lang);
    
    // Fetch the meeting page
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const html = await response.text();
    
    // Parse the HTML to extract meeting data
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    
    // Extract title
    const titleElement = doc.querySelector('h1');
    const title = titleElement?.textContent?.trim() || 'Unknown Meeting';
    
    // Extract date from title
    const dateMatch = title.match(/(\w+ \d+-\d+, \d{4})/);
    const date = dateMatch ? dateMatch[1] : getWeekDateRange();
    
    // Build links
    const webShareLink = buildWebShareLink(docid, locale);
    const appDeepLink = convertToAppLink(webShareLink, locale, docid);
    
    return {
      docid,
      title,
      date,
      url,
      webShareLink,
      appDeepLink,
      locale,
      language: lang
    };
    
  } catch (error) {
    console.error(`Error fetching meeting ${docid}:`, error);
    throw error;
  }
}

/**
 * Get meetings for a specific month
 */
export async function getMeetingsForMonth(year, month, locale = DEFAULT_LOCALE, lang = DEFAULT_LANGUAGE) {
  try {
    const url = MEETINGS_URL_PATTERN(year, month, locale, lang);
    
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const html = await response.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    
    // Extract all meeting links from the page
    const meetingLinks = doc.querySelectorAll('a[href*="/wol/d/"]');
    const meetings = [];
    
    for (const link of meetingLinks) {
      const href = link.getAttribute('href');
      const docidMatch = href.match(/\/(\d+)$/);
      
      if (docidMatch) {
        const docid = docidMatch[1];
        const title = link.textContent.trim();
        
        meetings.push({
          docid,
          title,
          url: `${WOL_BASE_URL}${href}`,
          webShareLink: buildWebShareLink(docid, locale),
          appDeepLink: convertToAppLink(null, locale, docid)
        });
      }
    }
    
    return meetings;
    
  } catch (error) {
    console.error(`Error fetching meetings for ${year}/${month}:`, error);
    throw error;
  }
}

/**
 * Simple in-memory cache
 */
const cache = new Map();
const CACHE_TTL = 1000 * 60 * 60; // 1 hour

export function getCachedMeeting(docid) {
  const cached = cache.get(docid);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return cached.data;
  }
  return null;
}

export function setCachedMeeting(docid, data) {
  cache.set(docid, {
    data,
    timestamp: Date.now()
  });
}
```

---

### Phase 3: React Components

#### Step 3.1: Custom Hook
**File:** `src/hooks/useMeeting.js`

```javascript
import { useState, useEffect } from 'react';
import { getCurrentWeekMeeting, getMeetingByDocId } from '../services/meetingService';

export function useMeeting(docid = null) {
  const [meeting, setMeeting] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchMeeting() {
      try {
        setLoading(true);
        setError(null);
        
        const data = docid 
          ? await getMeetingByDocId(docid)
          : await getCurrentWeekMeeting();
        
        setMeeting(data);
      } catch (err) {
        setError(err.message);
        console.error('Error fetching meeting:', err);
      } finally {
        setLoading(false);
      }
    }

    fetchMeeting();
  }, [docid]);

  return { meeting, loading, error };
}
```

#### Step 3.2: Meeting Card Component
**File:** `src/components/Meeting/MeetingCard.jsx`

```javascript
import React from 'react';
import { useMeeting } from '../../hooks/useMeeting';
import MeetingShareButton from './MeetingShareButton';
import './MeetingCard.css';

function MeetingCard({ docid = null }) {
  const { meeting, loading, error } = useMeeting(docid);

  if (loading) {
    return (
      <div className="meeting-card loading">
        <div className="spinner"></div>
        <p>Loading meeting...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="meeting-card error">
        <h3>Unable to load meeting</h3>
        <p>{error}</p>
      </div>
    );
  }

  if (!meeting) {
    return null;
  }

  return (
    <div className="meeting-card">
      <div className="meeting-header">
        <h2>{meeting.title}</h2>
        <span className="meeting-date">{meeting.date}</span>
      </div>
      
      <div className="meeting-actions">
        <MeetingShareButton 
          appLink={meeting.appDeepLink}
          webLink={meeting.url}
        />
        
        <a 
          href={meeting.url} 
          target="_blank" 
          rel="noopener noreferrer"
          className="btn-secondary"
        >
          View on wol.jw.org
        </a>
      </div>
    </div>
  );
}

export default MeetingCard;
```

#### Step 3.3: Share Button Component
**File:** `src/components/Meeting/MeetingShareButton.jsx`

```javascript
import React, { useState } from 'react';
import './MeetingShareButton.css';

function MeetingShareButton({ appLink, webLink }) {
  const [copied, setCopied] = useState(false);

  const handleOpenApp = () => {
    // Open the JW Library app deep link
    window.open(appLink, '_blank');
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(appLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <div className="meeting-share-button">
      <button 
        onClick={handleOpenApp}
        className="btn-primary"
      >
        📖 Open in JW Library
      </button>
      
      <button 
        onClick={handleCopyLink}
        className="btn-icon"
        title="Copy link"
      >
        {copied ? '✓' : '📋'}
      </button>
    </div>
  );
}

export default MeetingShareButton;
```

#### Step 3.4: CSS Styles
**File:** `src/components/Meeting/MeetingCard.css`

```css
.meeting-card {
  background: #fff;
  border-radius: 8px;
  padding: 20px;
  margin: 20px 0;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.meeting-card.loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 200px;
}

.meeting-card.error {
  border-left: 4px solid #f44336;
}

.meeting-header h2 {
  margin: 0 0 8px 0;
  color: #1e3a8a;
  font-size: 1.5rem;
}

.meeting-date {
  color: #666;
  font-size: 0.9rem;
}

.meeting-actions {
  display: flex;
  gap: 12px;
  margin-top: 16px;
}

.btn-primary {
  background: #5c6ac4;
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 6px;
  font-size: 1rem;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 8px;
  transition: background 0.2s;
}

.btn-primary:hover {
  background: #4c5ab8;
}

.btn-secondary {
  background: #f3f4f6;
  color: #374151;
  border: 1px solid #d1d5db;
  padding: 12px 24px;
  border-radius: 6px;
  text-decoration: none;
  font-size: 1rem;
  transition: background 0.2s;
}

.btn-secondary:hover {
  background: #e5e7eb;
}

.btn-icon {
  background: #f3f4f6;
  border: 1px solid #d1d5db;
  padding: 12px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 1.2rem;
  transition: background 0.2s;
}

.btn-icon:hover {
  background: #e5e7eb;
}

.spinner {
  border: 4px solid #f3f3f3;
  border-top: 4px solid #5c6ac4;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
```

**File:** `src/components/Meeting/MeetingShareButton.css`

```css
.meeting-share-button {
  display: flex;
  gap: 8px;
  align-items: center;
}
```

---

### Phase 4: Integration

#### Step 4.1: Add to Main App
**File:** `src/App.jsx` (or wherever you have your main component)

```javascript
import React from 'react';
import MeetingCard from './components/Meeting/MeetingCard';
// ... other imports

function App() {
  return (
    <div className="app">
      {/* ...existing content */}
      
      {/* Add meeting card */}
      <section className="meeting-section">
        <h1>This Week's Meeting</h1>
        <MeetingCard />
      </section>
      
      {/* ...rest of app */}
    </div>
  );
}

export default App;
```

---

### Phase 5: Testing

#### Step 5.1: Unit Tests
**File:** `src/services/__tests__/linkConverter.test.js`

```javascript
import { convertToAppLink, buildWebShareLink } from '../linkConverter';

describe('Link Converter', () => {
  test('converts web share link to app link', () => {
    const webLink = 'https://www.jw.org/finder?wtlocale=E&docid=2025642&srctype=wol&srcid=share';
    const appLink = convertToAppLink(webLink);
    
    expect(appLink).toBe('https://www.jw.org/finder?srcid=jwlshare&wtlocale=E&prefer=lang&docid=2025642');
  });
  
  test('builds web share link from docid', () => {
    const link = buildWebShareLink('2025642', 'E');
    
    expect(link).toContain('docid=2025642');
    expect(link).toContain('wtlocale=E');
    expect(link).toContain('srcid=share');
  });
});
```

#### Step 5.2: Integration Tests
**File:** `src/services/__tests__/meetingService.test.js`

```javascript
import { getCurrentWeekMeeting, getMeetingByDocId } from '../meetingService';

describe('Meeting Service', () => {
  test('gets current week meeting', async () => {
    const meeting = await getCurrentWeekMeeting();
    
    expect(meeting).toHaveProperty('docid');
    expect(meeting).toHaveProperty('title');
    expect(meeting).toHaveProperty('appDeepLink');
  });
  
  test('gets specific meeting by docid', async () => {
    const meeting = await getMeetingByDocId('2025642');
    
    expect(meeting.docid).toBe('2025642');
    expect(meeting.appDeepLink).toContain('docid=2025642');
  });
});
```

---

## 📦 Dependencies

Add to `package.json`:

```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  },
  "devDependencies": {
    "@testing-library/react": "^14.0.0",
    "@testing-library/jest-dom": "^6.1.0",
    "jest": "^29.7.0"
  }
}
```

---

## 🚀 Deployment Checklist

- [ ] Install dependencies
- [ ] Implement utility functions (Phase 1)
- [ ] Implement meeting service (Phase 2)
- [ ] Create React components (Phase 3)
- [ ] Integrate into main app (Phase 4)
- [ ] Write and run tests (Phase 5)
- [ ] Test in development environment
- [ ] Add error boundaries
- [ ] Add loading states
- [ ] Implement caching
- [ ] Test on mobile devices
- [ ] Test deep links on iOS/Android
- [ ] Deploy to production

---

## 🔄 Alternative: Backend API Approach

If you prefer to handle this server-side:

### Backend Route
**File:** `server/routes/meetings.js`

```javascript
const express = require('express');
const router = express.Router();
const { getCurrentWeekMeeting, getMeetingByDocId } = require('../services/meetingScraper');

// GET /api/meetings/current
router.get('/current', async (req, res) => {
  try {
    const { locale = 'E', lang = 'en' } = req.query;
    const meeting = await getCurrentWeekMeeting(locale, lang);
    res.json(meeting);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/meetings/:docid
router.get('/:docid', async (req, res) => {
  try {
    const { docid } = req.params;
    const { locale = 'E', lang = 'en' } = req.query;
    const meeting = await getMeetingByDocId(docid, locale, lang);
    res.json(meeting);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
```

### Frontend API Client
**File:** `src/services/api.js`

```javascript
const API_BASE = process.env.REACT_APP_API_URL || '/api';

export async function getCurrentMeeting(locale = 'E', lang = 'en') {
  const response = await fetch(`${API_BASE}/meetings/current?locale=${locale}&lang=${lang}`);
  if (!response.ok) throw new Error('Failed to fetch meeting');
  return response.json();
}

export async function getMeeting(docid, locale = 'E', lang = 'en') {
  const response = await fetch(`${API_BASE}/meetings/${docid}?locale=${locale}&lang=${lang}`);
  if (!response.ok) throw new Error('Failed to fetch meeting');
  return response.json();
}
```

---

## 🎨 UI/UX Enhancements

### 1. Week Navigator
Allow users to navigate between weeks:

```javascript
function MeetingWeekNavigator({ onWeekChange }) {
  const [currentWeek, setCurrentWeek] = useState(getCurrentWeekNumber());
  
  const goToPreviousWeek = () => {
    setCurrentWeek(prev => prev - 1);
    onWeekChange(currentWeek - 1);
  };
  
  const goToNextWeek = () => {
    setCurrentWeek(prev => prev + 1);
    onWeekChange(currentWeek + 1);
  };
  
  return (
    <div className="week-navigator">
      <button onClick={goToPreviousWeek}>← Previous</button>
      <span>Week {currentWeek}</span>
      <button onClick={goToNextWeek}>Next →</button>
    </div>
  );
}
```

### 2. Month View
Show all meetings for a month:

```javascript
function MonthMeetingList({ year, month }) {
  const [meetings, setMeetings] = useState([]);
  
  useEffect(() => {
    getMeetingsForMonth(year, month).then(setMeetings);
  }, [year, month]);
  
  return (
    <div className="month-meetings">
      {meetings.map(meeting => (
        <MeetingCard key={meeting.docid} docid={meeting.docid} />
      ))}
    </div>
  );
}
```

---

## 🐛 Error Handling

### Network Errors
```javascript
try {
  const meeting = await getCurrentWeekMeeting();
} catch (error) {
  if (error.message.includes('Network')) {
    // Show offline message
    showNotification('Please check your internet connection');
  } else if (error.message.includes('404')) {
    // Meeting not found
    showNotification('Meeting not yet available');
  } else {
    // Generic error
    showNotification('Unable to load meeting');
  }
}
```

### CORS Issues
If fetching from browser has CORS issues, use a proxy:

```javascript
// Option 1: Use proxy in package.json
{
  "proxy": "https://wol.jw.org"
}

// Option 2: Use CORS proxy
const CORS_PROXY = 'https://corsproxy.io/?';
const url = `${CORS_PROXY}${encodeURIComponent(meetingUrl)}`;
```

---

## 📱 Mobile Considerations

### Deep Link Handling

For iOS:
```javascript
const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

function openInApp(appLink) {
  if (isMobile) {
    // Try to open in app
    window.location.href = appLink;
    
    // Fallback to App Store if app not installed
    setTimeout(() => {
      window.location.href = 'https://apps.apple.com/app/jw-library/id672417831';
    }, 2000);
  } else {
    // Desktop: open in new tab
    window.open(appLink, '_blank');
  }
}
```

---

## 📊 Analytics (Optional)

Track meeting link clicks:

```javascript
function trackMeetingOpen(docid) {
  // Google Analytics
  gtag('event', 'meeting_open', {
    'meeting_docid': docid,
    'meeting_source': 'jw_news_app'
  });
  
  // Or custom analytics
  fetch('/api/analytics/meeting-click', {
    method: 'POST',
    body: JSON.stringify({ docid, timestamp: Date.now() })
  });
}
```

---

## 🔐 Security Considerations

1. **Rate Limiting**: Don't hammer wol.jw.org
2. **Caching**: Cache meeting data for at least 1 hour
3. **Input Validation**: Validate docid format
4. **Error Messages**: Don't expose internal errors to users

---

## ✅ Testing Checklist

- [ ] Test with current week
- [ ] Test with past weeks
- [ ] Test with future weeks (should fail gracefully)
- [ ] Test link conversion
- [ ] Test on desktop browser
- [ ] Test on mobile Safari (iOS)
- [ ] Test on Chrome (Android)
- [ ] Test deep link on device with JW Library installed
- [ ] Test deep link on device without JW Library
- [ ] Test with slow network
- [ ] Test with no network
- [ ] Test different locales (Spanish, French, etc.)

---

## 🎯 Success Metrics

- Time to load meeting: < 2 seconds
- Link conversion accuracy: 100%
- Deep link success rate: > 95%
- Cache hit rate: > 80%
- Error rate: < 1%

---

## 📝 Next Steps for Claude Code

1. **Start with Phase 1**: Implement utility functions first
2. **Test each function**: Make sure link conversion works perfectly
3. **Build Phase 2**: Implement meeting service
4. **Create Phase 3**: Build React components
5. **Integrate Phase 4**: Add to main app
6. **Polish**: Add error handling, loading states, styles

---

## 💡 Future Enhancements

- [ ] Push notifications for new meetings
- [ ] Calendar integration
- [ ] Download meeting materials
- [ ] Multi-language support
- [ ] Offline mode
- [ ] Meeting reminders
- [ ] Share meeting with friends
- [ ] Sync with JW Library app
- [ ] Display meeting parts breakdown
- [ ] Video/audio media preview

---

## 📞 Support & Documentation

- WOL.JW.ORG API: (Unofficial, reverse-engineered)
- JW Library Deep Links: [Documentation needed]
- React Documentation: https://react.dev
- Testing Library: https://testing-library.com

---

## 🎉 Done!

This plan provides everything Claude Code needs to implement the feature. Start with Phase 1 and work through sequentially. Each phase builds on the previous one.

**Estimated Implementation Time:** 4-6 hours for experienced developer
