# Claude Code Quick Start Guide

## 🚀 For Claude Code: Step-by-Step Implementation

This is a condensed version specifically for Claude Code to implement the meeting share link feature in JW-News.

---

## 📋 Prerequisites Check

```bash
# 1. Navigate to project
cd /path/to/JW-News

# 2. Check project structure
ls -la src/

# 3. Check if it's React
cat package.json | grep "react"

# 4. Install any missing dependencies
npm install
```

---

## 🎯 Implementation Order

### STEP 1: Create Utilities (10 min)

Create these files in order:

1. `src/utils/constants.js` - Configuration
2. `src/services/linkConverter.js` - Link conversion logic
3. `src/services/dateUtils.js` - Date/week calculations
4. `src/services/meetingService.js` - Core meeting logic

**Action for Claude Code:**
```bash
# Create directories
mkdir -p src/services src/utils src/components/Meeting src/hooks

# Copy the utility files from the plan
# Test each file independently
```

### STEP 2: Create React Hook (5 min)

Create: `src/hooks/useMeeting.js`

**Test it:**
```javascript
// In a test component
import { useMeeting } from './hooks/useMeeting';

function TestComponent() {
  const { meeting, loading, error } = useMeeting();
  console.log({ meeting, loading, error });
  return null;
}
```

### STEP 3: Create UI Components (15 min)

Create in this order:
1. `src/components/Meeting/MeetingShareButton.jsx` - The button
2. `src/components/Meeting/MeetingCard.jsx` - The card
3. `src/components/Meeting/MeetingCard.css` - Styles
4. `src/components/Meeting/MeetingShareButton.css` - Button styles

### STEP 4: Integrate (5 min)

Add `<MeetingCard />` to your main app component.

### STEP 5: Test (10 min)

```bash
npm start
# Open browser to test
```

---

## 🔥 Quick Commands for Claude Code

### Initialize Feature
```bash
# Create all directories at once
mkdir -p src/{services,utils,components/Meeting,hooks}
```

### Test Link Conversion
```javascript
// Run this in browser console
import { convertToAppLink } from './services/linkConverter';

const webLink = "https://www.jw.org/finder?wtlocale=E&docid=2025642&srctype=wol&srcid=share";
const appLink = convertToAppLink(webLink);
console.log('App Link:', appLink);
// Should output: https://www.jw.org/finder?srcid=jwlshare&wtlocale=E&prefer=lang&docid=2025642
```

### Test Meeting Service
```javascript
// In React DevTools or browser console
import { getCurrentWeekMeeting } from './services/meetingService';

getCurrentWeekMeeting().then(console.log);
// Should log meeting object with appDeepLink
```

---

## 🐛 Common Issues & Fixes

### Issue 1: CORS Error
**Error:** `Access to fetch blocked by CORS policy`

**Fix 1 - Dev Proxy:**
```json
// In package.json
{
  "proxy": "https://wol.jw.org"
}
```

**Fix 2 - Backend Proxy:**
Create a backend endpoint that fetches the data (see plan)

**Fix 3 - CORS Proxy (Quick & Dirty):**
```javascript
const CORS_PROXY = 'https://api.allorigins.win/raw?url=';
const url = `${CORS_PROXY}${encodeURIComponent(meetingUrl)}`;
```

### Issue 2: DOMParser not working
**Error:** `DOMParser is not defined`

**Fix:** Use a proper HTML parser:
```bash
npm install node-html-parser
```

```javascript
import { parse } from 'node-html-parser';

const root = parse(html);
const title = root.querySelector('h1')?.text;
```

### Issue 3: Network requests blocked
**Error:** Browser blocks the request

**Fix:** Move scraping to backend (see Alternative Backend Approach in main plan)

---

## 🎯 Minimum Viable Product (MVP)

If you want to ship fast, implement just these:

### MVP Files (4 files only):
1. `src/services/linkConverter.js` - Core logic
2. `src/services/dateUtils.js` - Get current week
3. `src/components/Meeting/MeetingCard.jsx` - Display + button
4. `src/components/Meeting/MeetingCard.css` - Basic styles

### MVP MeetingCard (Simplified):
```javascript
import React, { useState, useEffect } from 'react';
import { getCurrentWeekDocId } from '../services/dateUtils';
import { convertToAppLink } from '../services/linkConverter';

function MeetingCard() {
  const [docid, setDocid] = useState('');
  const [appLink, setAppLink] = useState('');
  
  useEffect(() => {
    const id = getCurrentWeekDocId();
    setDocid(id);
    setAppLink(convertToAppLink(null, 'E', id));
  }, []);
  
  return (
    <div style={{ padding: '20px', background: '#f5f5f5', borderRadius: '8px' }}>
      <h2>This Week's Meeting</h2>
      <p>Document ID: {docid}</p>
      <button 
        onClick={() => window.open(appLink, '_blank')}
        style={{
          background: '#5c6ac4',
          color: 'white',
          border: 'none',
          padding: '12px 24px',
          borderRadius: '6px',
          cursor: 'pointer'
        }}
      >
        📖 Open in JW Library
      </button>
    </div>
  );
}

export default MeetingCard;
```

This MVP version:
- ✅ No network requests (no CORS issues!)
- ✅ No HTML parsing needed
- ✅ Works immediately
- ✅ Generates correct deep links
- ❌ No meeting title/date (user can see in app)

**Trade-off:** User doesn't see meeting title, but the link works perfectly!

---

## 🔄 Progressive Enhancement

After MVP works, enhance step by step:

1. **Add meeting title** - Hardcode or use a JSON mapping
2. **Add network fetching** - Get real meeting data
3. **Add error handling** - Loading states, errors
4. **Add week navigation** - Previous/next buttons
5. **Add caching** - Store fetched meetings
6. **Add styling** - Make it pretty

---

## 📝 Code Review Checklist for Claude Code

Before committing, verify:

- [ ] Link conversion works correctly
- [ ] Current week docid calculation is accurate
- [ ] App deep link has correct format
- [ ] Component renders without errors
- [ ] Button opens link in new tab
- [ ] Code follows project style guide
- [ ] No console errors
- [ ] Works on mobile
- [ ] Handles edge cases (no internet, wrong docid)

---

## 🚢 Deployment Steps

```bash
# 1. Test locally
npm start

# 2. Build for production
npm run build

# 3. Test production build
npm run preview

# 4. Commit
git add .
git commit -m "feat: add JW Library meeting share link integration"

# 5. Push
git push origin main

# 6. Deploy (if using Netlify/Vercel)
# Auto-deploys from GitHub
```

---

## 📊 Testing Checklist

Test these scenarios:

1. **Basic functionality**
   - [ ] Page loads without errors
   - [ ] Meeting card displays
   - [ ] Button is clickable
   - [ ] Link opens in new tab

2. **Link correctness**
   - [ ] Link has `srcid=jwlshare`
   - [ ] Link has `prefer=lang`
   - [ ] Link has correct `docid`
   - [ ] Link has correct `wtlocale`

3. **Edge cases**
   - [ ] Works on Monday (start of week)
   - [ ] Works on Sunday (end of week)
   - [ ] Works at year boundary (Dec 31 → Jan 1)
   - [ ] Week 1 of year calculates correctly

4. **Devices**
   - [ ] Desktop Chrome
   - [ ] Desktop Firefox
   - [ ] Mobile Safari (iOS)
   - [ ] Mobile Chrome (Android)

5. **Deep link on device**
   - [ ] Opens JW Library if installed
   - [ ] Fallback to web if not installed

---

## 🎉 Success Criteria

You're done when:

1. ✅ Meeting card shows on homepage
2. ✅ "Open in JW Library" button visible
3. ✅ Clicking button opens correct deep link
4. ✅ Link format matches: `https://www.jw.org/finder?srcid=jwlshare&wtlocale=E&prefer=lang&docid=XXXXXX`
5. ✅ Works on mobile device with JW Library installed
6. ✅ No console errors
7. ✅ Code committed to GitHub

---

## 🆘 If Stuck

### Quick Debug Commands

```javascript
// Test docid calculation
import { getCurrentWeekDocId } from './services/dateUtils';
console.log('Current week docid:', getCurrentWeekDocId());

// Test link conversion
import { convertToAppLink } from './services/linkConverter';
const link = convertToAppLink(null, 'E', '2025642');
console.log('App link:', link);

// Test component rendering
console.log('MeetingCard mounted');
```

### Emergency Simple Version

If all else fails, use this dead-simple version:

```javascript
function QuickMeetingLink() {
  const openMeeting = () => {
    // Hardcode current meeting docid (update weekly)
    const docid = '2025642';
    const link = `https://www.jw.org/finder?srcid=jwlshare&wtlocale=E&prefer=lang&docid=${docid}`;
    window.open(link, '_blank');
  };
  
  return <button onClick={openMeeting}>Open Meeting in JW Library</button>;
}
```

Then gradually improve it!

---

## 📚 Resources

- Main plan: `JW_NEWS_IMPLEMENTATION_PLAN.md`
- React Docs: https://react.dev
- JW.org URLs: https://wol.jw.org
- Test meeting: https://wol.jw.org/en/wol/d/r1/lp-e/2025642

---

**Estimated Time:** 30-60 minutes for MVP, 2-4 hours for full implementation

**Priority:** Start with MVP, ship it, then enhance!
