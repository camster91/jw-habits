/**
 * MeetingCard Component (MVP Version)
 * 
 * This is a minimal viable product that works without network requests.
 * It generates the correct deep link for the current week's meeting.
 * 
 * Usage:
 *   import MeetingCard from './components/Meeting/MeetingCard';
 *   <MeetingCard />
 */

import React, { useState, useEffect } from 'react';
import { getCurrentWeekDocId, getWeekDateRange } from '../../services/dateUtils';
import { convertToAppLink } from '../../services/linkConverter';
import './MeetingCard.css';

function MeetingCard({ locale = 'E', language = 'en' }) {
  const [docid, setDocid] = useState('');
  const [appLink, setAppLink] = useState('');
  const [dateRange, setDateRange] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    try {
      // Get current week's document ID
      const id = getCurrentWeekDocId();
      setDocid(id);
      
      // Generate app deep link
      const link = convertToAppLink(null, locale, id);
      setAppLink(link);
      
      // Get date range
      const range = getWeekDateRange();
      setDateRange(range);
    } catch (error) {
      console.error('Error initializing meeting card:', error);
    }
  }, [locale]);

  const handleOpenApp = () => {
    if (appLink) {
      // Detect mobile
      const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
      
      if (isMobile) {
        // On mobile, try to open in app
        window.location.href = appLink;
        
        // Fallback to App Store if app not installed (after 2 seconds)
        setTimeout(() => {
          const isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent);
          const appStoreUrl = isIOS
            ? 'https://apps.apple.com/app/jw-library/id672417831'
            : 'https://play.google.com/store/apps/details?id=org.jw.jwlibrary.mobile';
          window.location.href = appStoreUrl;
        }, 2000);
      } else {
        // On desktop, open in new tab
        window.open(appLink, '_blank', 'noopener,noreferrer');
      }
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(appLink);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy link:', error);
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = appLink;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleViewOnWeb = () => {
    const webUrl = `https://wol.jw.org/${language}/wol/d/r1/lp-${locale.toLowerCase()}/${docid}`;
    window.open(webUrl, '_blank', 'noopener,noreferrer');
  };

  if (!docid) {
    return null;
  }

  return (
    <div className="meeting-card">
      <div className="meeting-header">
        <div className="meeting-icon">📖</div>
        <div className="meeting-info">
          <h2 className="meeting-title">This Week's Meeting</h2>
          <p className="meeting-date">{dateRange}</p>
        </div>
      </div>
      
      <div className="meeting-actions">
        <button 
          onClick={handleOpenApp}
          className="btn-primary"
          title="Open meeting in JW Library app"
        >
          📱 Open in JW Library
        </button>
        
        <button 
          onClick={handleCopyLink}
          className="btn-secondary"
          title={copied ? 'Copied!' : 'Copy link'}
        >
          {copied ? '✓ Copied' : '📋 Copy Link'}
        </button>
        
        <button 
          onClick={handleViewOnWeb}
          className="btn-secondary"
          title="View on wol.jw.org"
        >
          🌐 View Online
        </button>
      </div>
      
      <div className="meeting-meta">
        <small className="meeting-docid">Document ID: {docid}</small>
      </div>
    </div>
  );
}

export default MeetingCard;
