/**
 * Date Utilities for JW Meeting Calculations
 * Handles week number calculations and docid generation
 */

/**
 * Get current week number (1-52)
 * Uses ISO 8601 week date system
 * @returns {number} Current week number
 */
export function getCurrentWeekNumber() {
  const now = new Date();
  
  // Set to nearest Thursday (current date + 4 - current day number)
  // Make Sunday's day number 7
  const dayNum = now.getDay() || 7;
  now.setDate(now.getDate() + 4 - dayNum);
  
  // Get first day of year
  const yearStart = new Date(now.getFullYear(), 0, 1);
  
  // Calculate full weeks to nearest Thursday
  const weekNum = Math.ceil((((now - yearStart) / 86400000) + 1) / 7);
  
  return weekNum;
}

/**
 * Get current year
 * @returns {number} Current year
 */
export function getCurrentYear() {
  return new Date().getFullYear();
}

/**
 * Calculate docid for a given year and week
 * Format: YEAR + 0 + WEEK (e.g., 2025 + 0 + 42 = 2025642)
 * 
 * @param {number} year - Year (e.g., 2025)
 * @param {number} week - Week number (1-52)
 * @returns {string} Document ID
 * 
 * @example
 * getDocIdForWeek(2025, 42)
 * // Returns: "2025642"
 */
export function getDocIdForWeek(year, week) {
  // Ensure week is 2 digits (pad with leading zero if needed)
  const weekPadded = week.toString().padStart(2, '0');
  return `${year}6${weekPadded}`;
}

/**
 * Get current week's docid
 * @returns {string} Current week's document ID
 * 
 * @example
 * getCurrentWeekDocId()
 * // Returns: "2025642" (if current week is 42 in 2025)
 */
export function getCurrentWeekDocId() {
  const year = getCurrentYear();
  const week = getCurrentWeekNumber();
  return getDocIdForWeek(year, week);
}

/**
 * Get date range string for a week
 * @param {Date} date - Any date in the week (defaults to today)
 * @returns {string} Date range (e.g., "January 6-12, 2025")
 */
export function getWeekDateRange(date = new Date()) {
  // Clone date to avoid mutation
  const targetDate = new Date(date);
  
  // Get Monday of the week (meeting week starts on Monday)
  const day = targetDate.getDay();
  const diff = targetDate.getDate() - day + (day === 0 ? -6 : 1);
  const monday = new Date(targetDate.setDate(diff));
  
  // Get Sunday (end of meeting week)
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  
  const monthName = monday.toLocaleString('en-US', { month: 'long' });
  const year = monday.getFullYear();
  
  // Handle month transition
  if (monday.getMonth() === sunday.getMonth()) {
    return `${monthName} ${monday.getDate()}-${sunday.getDate()}, ${year}`;
  } else {
    const sundayMonthName = sunday.toLocaleString('en-US', { month: 'long' });
    return `${monthName} ${monday.getDate()}-${sundayMonthName} ${sunday.getDate()}, ${year}`;
  }
}

/**
 * Get Monday of current week
 * @returns {Date} Monday of the current week
 */
export function getMondayOfCurrentWeek() {
  const now = new Date();
  const day = now.getDay();
  const diff = now.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(now.setDate(diff));
}

/**
 * Check if a date is in the current meeting week
 * @param {Date} date - Date to check
 * @returns {boolean} True if date is in current meeting week
 */
export function isCurrentMeetingWeek(date = new Date()) {
  const monday = getMondayOfCurrentWeek();
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  
  return date >= monday && date <= sunday;
}

/**
 * Get docid for next week
 * @returns {string} Next week's document ID
 */
export function getNextWeekDocId() {
  const year = getCurrentYear();
  let week = getCurrentWeekNumber() + 1;
  
  // Handle year transition
  if (week > 52) {
    week = 1;
    return getDocIdForWeek(year + 1, week);
  }
  
  return getDocIdForWeek(year, week);
}

/**
 * Get docid for previous week
 * @returns {string} Previous week's document ID
 */
export function getPreviousWeekDocId() {
  const year = getCurrentYear();
  let week = getCurrentWeekNumber() - 1;
  
  // Handle year transition
  if (week < 1) {
    week = 52;
    return getDocIdForWeek(year - 1, week);
  }
  
  return getDocIdForWeek(year, week);
}
